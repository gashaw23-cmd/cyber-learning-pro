# EduAI Pro — Hebrew Quiz Generator (GPT‑4o)

אפליקציית ווב מודרנית בעברית ליצירת **מבחנים אמריקאיים** מתוך מסמך (PDF / DOCX / TXT).
המערכת כוללת מסך התחברות להזנת OpenAI API Key *מקומית בלבד*, העלאת מסמך, יצירת מבחן, בדיקה, ציון וניתוח.

## פריסה מהירה (Vercel)
1. הורידו את הקובץ `EduAI_Pro_Web.zip` ופרסו לתיקייה.
2. התחברו אל https://vercel.com → New Project → Import (מקומי או Git).
3. ודאו ש־`vercel.json` קיים. אין חובה להגדיר משתני סביבה (המערכת תשתמש ב‑x-api-key מהלקוח).
4. Deploy — תקבלו לינק מיד.

> אופציונלי: הגדירו `OPENAI_API_KEY` בסביבה ב־Vercel כדי לא להזין מפתח מהדפדפן.

## הרצה מקומית (אופציונלי)
ניתן להשתמש ב־Vercel CLI:
```bash
npm i -g vercel
vercel dev
```
או לפרוס על שרת node משלכם (צריך למפות את `api/*.js` כ־endpoints).

## אבטחה
- המפתח נשמר מקומית ב־LocalStorage אצל המשתמש. אפשר למחוק בכפתור "מחיקת מפתח".
- בקשות ל־/api שולחות את המפתח בכותרת `x-api-key` לקריאה ישירה ל‑OpenAI; השרת לא שומר לוגים.

## קבצים
- `public/index.html` — ממשק מודרני בעברית (RTL).
- `api/extract-text.js` — חילוץ טקסט מ־PDF/DOCX/TXT.
- `api/generate-questions.js` — יצירת שאלות דרך GPT‑4o.

בהצלחה! ✨
