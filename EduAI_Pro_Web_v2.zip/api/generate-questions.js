// api/generate-questions.js
const fetch = require('node-fetch');

module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  try {
    const { text, numQuestions = 8, difficulty = 'בינוני' } = req.body || {};
    if (!text || !String(text).trim()) return res.status(400).json({ error: 'no text' });

    // Key priority: from header x-api-key (client personal) else from env
    const key = req.headers['x-api-key'] || process.env.OPENAI_API_KEY;
    if (!key) return res.status(401).json({ error: 'missing OpenAI API key' });

    const system = `את/ה מחולל/ת מבחן בעברית. החזר/י JSON בלבד במבנה:
{
  "questions": [
    { "q": "נוסח השאלה", "options": ["תשובה א","תשובה ב","תשובה ג","תשובה ד"], "answer": 0, "explanation":"למה זו התשובה", "topic":"נושא/כותרת" }
  ]
}
דרישות: שאלות אמריקאיות בלבד עם 4 אפשרויות; רק אחת נכונה; שאלות באיכות בינונית‑קשה בהתאם לרמת הקושי: ${difficulty}. אל תמציא/י ידע שאינו מופיע בטקסט. הפק בין ${numQuestions} שאלות.`;

    const user = `טקסט מקור (ייתכן שנחתך):\n\n${String(text).slice(0, 35000)}\n\nצור/י מבחן בהתאם.`;

    const payload = {
      model: "gpt-4o",
      messages: [
        { role: "system", content: system },
        { role: "user", content: user }
      ],
      temperature: 0.6,
      max_tokens: 1800
    };

    const resp = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${key}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(payload)
    });

    const txt = await resp.text();
    if (!resp.ok) return res.status(resp.status).json({ error: txt });

    // Try parse JSON from content
    let content = "";
    try {
      const data = JSON.parse(txt);
      content = data.choices?.[0]?.message?.content || "";
    } catch {
      content = txt;
    }

    // Pull JSON object from content
    let jsonText = content;
    const first = content.indexOf("{");
    if (first > -1) jsonText = content.slice(first);
    let parsed;
    try {
      parsed = JSON.parse(jsonText);
    } catch (e) {
      return res.status(200).json({ raw: content, error: "failed_to_parse_json" });
    }

    return res.json({ questions: parsed.questions || parsed });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ error: 'server_error', details: String(e) });
  }
};
